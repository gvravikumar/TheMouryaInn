package com.gvrk.four.themouryainn;

/**
 * Created by G V RAVI KUMAR on 6/17/2018.
 */

public interface paymentDoneInterface {
    void movingFragment();
}
